package com.online.booking.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name ="country")
public class Country {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name ="country")
    private String country;

    @Column(name = "is_active", columnDefinition = "BIT(1) default b'1'" )
    private Boolean isActive;

}
