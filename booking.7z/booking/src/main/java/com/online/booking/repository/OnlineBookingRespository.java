package com.online.booking.repository;

import com.online.booking.entity.OnlineBooking;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;

@Repository
public interface OnlineBookingRespository extends JpaRepository<OnlineBooking, Integer> {
    @Transactional
    @Modifying
    @Query(value = "insert into  OnlineBooking(theaterDetailsId, bookingTime ) values(  :theaterDetailsId, :bookingTime  ) ")
    Integer createBookingTicket(@Param("theaterDetailsId") Integer theaterDetailsId, @Param("bookingTime") Timestamp bookingTime);
}
