package com.online.booking.service.Impl;

import com.online.booking.controller.dao.BrowseRespositoryDao;
import com.online.booking.controller.dao.LocationDao;
import com.online.booking.controller.dao.OnlineBookingDao;
import com.online.booking.controller.dao.TheaterDetailsDao;
import com.online.booking.model.SeatStatus;
import com.online.booking.model.BookedByUser;
import com.online.booking.service.BrowseService;
import com.online.booking.utility.JacksonJsonParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class BrowseServiceImp implements BrowseService {

    @Autowired
    BrowseRespositoryDao browseRespositoryDao;
    @Autowired
    LocationDao locationDao;
    @Autowired
    OnlineBookingDao onlineBookingDao;
    @Autowired
    TheaterDetailsDao theaterDetailsDao;
    @Autowired
    JacksonJsonParser jacksonJsonParser;

    @Override
    public Optional<List<String>> browseTheatres(Integer townId, Integer movieDetailsId) {
        Optional<Long> locationId = Optional.ofNullable(locationDao.findByTownId(townId));
        return locationId.isPresent()
                ? Optional.of(browseRespositoryDao.findByAlltheatres(movieDetailsId, locationId.get()))
                : Optional.empty();
    }

    private Boolean checkSeatAvailaibility(BookedByUser bookedByUser, Optional<String> seatStatusInJson) {

        if (seatStatusInJson.isEmpty())
            return true;

        Optional<Map<String, SeatStatus>> allSeatsStatus = Optional.of(jacksonJsonParser.readJsonData(seatStatusInJson));
        HashSet<String> seatSelected = bookedByUser.getTotalNoOfSelectedSeats();

        //canceled status will be removed after process rollback.thus not considered in map.
        for (String seatNo : seatSelected) {
            StringBuilder finalSeatNo = new StringBuilder(seatNo + "ShowNum" + bookedByUser.getShowNum());
            if (allSeatsStatus.stream().anyMatch(n -> n.containsKey(finalSeatNo.toString())))
                return false;
        }
        return true;
    }

    private Optional<String> getSeatStatus(Integer theaterDetailsId) {
        Optional<String> jsonData = Optional.ofNullable(browseRespositoryDao.findBytheaterDetailsIdAndGetstatus(theaterDetailsId));
        return jsonData;
    }

    private String updateSeatStatusInJson(BookedByUser bookedByUser, Optional<String> seatStatusInJson) {

        Map<String, SeatStatus> jsonDataInMap;
        if (seatStatusInJson.isPresent())
            jsonDataInMap = jacksonJsonParser.readJsonData(seatStatusInJson);
        else
            jsonDataInMap = new HashMap<String, SeatStatus>();

        HashSet<String> selectedSeat = bookedByUser.getTotalNoOfSelectedSeats();

        // add seatNo + CS1 as key & status as val.
        for (String seatNum : selectedSeat) {
            jsonDataInMap.put(seatNum + "ShowNum" + bookedByUser.getShowNum(), SeatStatus.RESERVED);
        }

        String jsonData = jacksonJsonParser.convertIntoJson(jsonDataInMap);
        //convert into json.
        return jsonData;
    }

    private void writeSeatStatusInDB(String seatDetailInJSON, BookedByUser bookedByUser) {

        onlineBookingDao.createBookingTicket(bookedByUser.getTheaterDetailsId(), bookedByUser.getBookingTime());
        theaterDetailsDao.updateTheaterDetailsById(bookedByUser.getTheaterDetailsId(), seatDetailInJSON);
        Integer currentAvailableSeat = theaterDetailsDao.findByIdAndGetTotalAvailableSeats(bookedByUser.getTheaterDetailsId());
        currentAvailableSeat = currentAvailableSeat - bookedByUser.getTotalNoOfSelectedSeats().size();
        theaterDetailsDao.updateTotalSeatsById(bookedByUser.getTheaterDetailsId(), currentAvailableSeat);

    }

    @Override
    public boolean bookTickets(BookedByUser bookedByUser) {
        //get seat status from db.
        synchronized (this) {
            if (!numberOfSeatsValidation(bookedByUser))
                return false;

            Optional<String> seatStatusInJson = getSeatStatus(bookedByUser.getTheaterDetailsId());
            if (checkSeatAvailaibility(bookedByUser, seatStatusInJson)) {
                String jsonData = updateSeatStatusInJson(bookedByUser, seatStatusInJson);
                writeSeatStatusInDB(jsonData, bookedByUser);
                /* further either call 3rd party payment service or expose respective controller
                 , if it fails then decrement total available seats.*/

                return true;
            }
        }
        return false;
    }

    private boolean numberOfSeatsValidation(BookedByUser bookedByUser) {

        boolean isActive = theaterDetailsDao.findByIdAndGetisActive(bookedByUser.getTheaterDetailsId());
        if (isActive) {
            Integer totalAvailableSeat = theaterDetailsDao.findByIdAndGetTotalAvailableSeats(bookedByUser.getTheaterDetailsId());
            if (bookedByUser.getTotalNoOfSelectedSeats().size() <= totalAvailableSeat)
                return true;
        }
        return false;
    }
}
