package com.online.booking.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.antlr.v4.runtime.misc.NotNull;

import java.sql.Blob;
import java.sql.Timestamp;
import java.util.HashSet;

@Entity
@Data
@Table(name = "theater_details")
public class TheaterDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;


    @Column(name = "theater_name", nullable = false)
    private String theaterName;


    @Column(name = "location_id", nullable = false)
    private Integer locationId;


    @Column(name = "movie_details_id", nullable = false)
    private Integer movieDetailsId;

    @Column(name = "totalAvailableSeats", nullable = false)
    private Integer totalAvailableSeats;

    @Column(name = "totalSeats", nullable = false)
    private Integer totalSeats;

    @Column(name ="seat_status")  // "RESERVED" status  while booking
    private String seatStatus;

    @Column(name = "show_number", nullable = false) //no of shows in each cinema
    private Integer showNumber;

    @JsonFormat(pattern = "MM/dd/yyyy")
    @Column(name = "movie_date_time", nullable = false)
    private Timestamp movieDateTime;

    @Column(name = "is_active", columnDefinition = "BIT(1) default b'1'" )
    private Boolean isActive;

}
