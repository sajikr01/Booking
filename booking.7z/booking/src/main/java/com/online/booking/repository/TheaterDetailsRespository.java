package com.online.booking.repository;

import com.online.booking.entity.TheaterDetails;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TheaterDetailsRespository extends JpaRepository<TheaterDetails, Integer> {
    @Transactional
    @Modifying
    @Query(value = "update TheaterDetails  set seatStatus = :seatStatus where  id = :id   ")
    Integer updateTheaterDetailsById(@Param("id") Integer id, @Param("seatStatus") String seatStatus);

    @Query(value = "select totalAvailableSeats  from TheaterDetails where  id = :id ")
    Integer findByIdAndGetTotalAvailableSeats(@Param("id") Integer id);

    @Query(value = "select isActive  from TheaterDetails where  id = :id ")
    boolean findByIdAndGetisActive(@Param("id") Integer id);

    @Transactional
    @Modifying
    @Query(value = "update TheaterDetails  set totalAvailableSeats = :totalAvailableSeats where  id = :id  ")
    Integer updateTotalSeatsById(@Param("id") Integer id, @Param("totalAvailableSeats") Integer totalAvailableSeats);

}
