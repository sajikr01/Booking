package com.online.booking.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name ="user_info")
public class UserInfo{

        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Long id;

        @Column(name ="userId")
        private String userId;

        @Column(name ="emailId")
        private String emailId;

        @Column(name ="contact_number")
        private String contactNumber;

        @Column(name = "is_active", columnDefinition = "BIT(1) default b'1'" )
        private Boolean isActive;

}
