package com.online.booking.controller;

import com.online.booking.model.BookedByUser;
import com.online.booking.service.BrowseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/movie")
public class BrowseController {

    @Autowired
    BrowseService browseService;

    @GetMapping("/browse/town/{townId}/selectedmovie/{selectedmovieId}")
    public ResponseEntity<Optional<List<String>>> browsing(@PathVariable Integer townId, @PathVariable Integer selectedmovieId) {

        Optional<List<String>> listOfTheaters = browseService.browseTheatres(townId, selectedmovieId);
        return listOfTheaters.isPresent()
                ? ResponseEntity.ok(listOfTheaters)
                : ResponseEntity.ok().build();

    }

    @PostMapping("/book-theatre")
    public ResponseEntity bookTicket(@RequestBody BookedByUser bookedByUser) {
        if (!isbookingTicketValid(Optional.ofNullable(bookedByUser))) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
        return Optional.of(browseService.bookTickets(bookedByUser)).get()
                ? ResponseEntity.ok("Ticket Booked Successfully")
                : ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
    }

    private boolean isbookingTicketValid(Optional<BookedByUser> bookedByUser) {

        if (bookedByUser.isEmpty())
            return false;

        return !bookedByUser.get().getTotalNoOfSelectedSeats().isEmpty()
                && bookedByUser.get().getShowNum() != null
                && bookedByUser.get().getBookingTime() != null
                && bookedByUser.get().getTheaterDetailsId() != null;
    }

}

