package com.online.booking.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name ="state")
public class State {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name ="state")
    private String state;

    @Column(name = "is_active", columnDefinition = "BIT(1) default b'1'" )
    private Boolean isActive;


}
