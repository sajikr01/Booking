package com.online.booking.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.sql.Timestamp;
import java.util.HashSet;

@Data
public class BookedByUser {

    private HashSet<String> totalNoOfSelectedSeats;
    private Integer showNum;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private Timestamp bookingTime;

    private Integer theaterDetailsId;

}
