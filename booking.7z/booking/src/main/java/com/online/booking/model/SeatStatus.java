package com.online.booking.model;

public enum SeatStatus {
    RESERVED, BOOKING,CANCELED,COMPLETED
}
