package com.online.booking.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.online.booking.model.SeatStatus;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.DynamicUpdate;

import java.sql.Blob;
import java.sql.Timestamp;
@Entity
@Data
@Table(name ="online_booking")
//@DynamicUpdate
public class OnlineBooking  {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name ="theater_details_id")
    private Integer theaterDetailsId;

    @Column(name ="payment_info_id")
    private Integer paymentInfoId;

    @JsonFormat(pattern="dd/MM/yyyy")
    @Column(name = "booking_time")
    private Timestamp bookingTime;

}
