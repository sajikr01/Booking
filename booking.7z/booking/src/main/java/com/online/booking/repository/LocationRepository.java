package com.online.booking.repository;

import com.online.booking.entity.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LocationRepository  extends JpaRepository<Location, Long> {
    @Query(value = "select id   from Location where townId =?1")
    Long findByTownId( @Param("townId") Integer townId);
}
