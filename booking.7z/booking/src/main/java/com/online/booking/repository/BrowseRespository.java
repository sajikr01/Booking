package com.online.booking.repository;

import com.online.booking.entity.TheaterDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
//public interface BrowseRespository extends Repository<TheaterDetails, String> {
public interface BrowseRespository extends JpaRepository<TheaterDetails, String> {

    @Query(value = "select theaterName , DATE_FORMAT(movieDateTime,'%h/%i/%p') , DATE_FORMAT(movieDateTime,'%d/%m/%Y')  from TheaterDetails where movieDetailsId =?1 and  locationId =?2")
   List<String> findByAlltheatres(
            @Param("movieDetailsId") Integer movieDetailsId,
            @Param("locationId") Long locationId);

   @Query(value = "select seatStatus  from TheaterDetails where id =?1" )
   String findBytheaterDetailsIdAndGetstatus(
           @Param("id") Integer id );

}
