package com.online.booking.controller.dao;

import com.online.booking.repository.BrowseRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BrowseRespositoryDao  {
    @Autowired
    BrowseRespository browseRespository;
    public List<String> findByAlltheatres(Integer movieDetailsId, Long locationId) {
        return browseRespository.findByAlltheatres(movieDetailsId, locationId);
    }
    public String findBytheaterDetailsIdAndGetstatus(Integer theaterDetailsId) {
        return browseRespository.findBytheaterDetailsIdAndGetstatus(theaterDetailsId);
    }
}
