package com.online.booking.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.Data;

import java.sql.Timestamp;
import java.util.HashSet;

@Entity
@Data
@Table(name ="movie_details")
public class MovieDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name ="movie_name")
    private String movieName;

    @Column(name ="language") // english, hindi etc
    private String language;

    @Column(name ="movie_genres") // drama, thriller etc
    private String movieGenres;

    @Column(name ="movie_dimensions") //2d,3D
    private String movieDimensions;

    @Column(name = "is_active", columnDefinition = "BIT(1) default b'1'" )
    private Boolean isActive;

}
