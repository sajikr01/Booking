package com.online.booking.controller.dao;

import com.online.booking.repository.TheaterDetailsRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TheaterDetailsDao  {

    @Autowired
    TheaterDetailsRespository theaterDetailsRespository;

    public Integer updateTheaterDetailsById(Integer id, String seatDetailInJSON) {
        return  theaterDetailsRespository.updateTheaterDetailsById(id, seatDetailInJSON);
    }

    public Integer findByIdAndGetTotalAvailableSeats(Integer id) {
        return  theaterDetailsRespository.findByIdAndGetTotalAvailableSeats(id);
    }

    public boolean findByIdAndGetisActive(Integer id) {
        return theaterDetailsRespository.findByIdAndGetisActive(id);
    }
    public Integer updateTotalSeatsById(Integer id, Integer totalAvailableSeats) {
        return theaterDetailsRespository.updateTotalSeatsById(id, totalAvailableSeats);
    }
}
