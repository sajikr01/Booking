package com.online.booking.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name ="location")
public class Location {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name ="town_id") //delhi NCR, mumbai , bangalore etc.
    private Integer townId;

    @Column(name ="sub_regions") // noida, gurgaon etc
    private String sub_regions;

    @Column(name ="zipcode")
    private String zipcode;

    @Column(name ="state_id")
    private Integer stateId;

    @Column(name ="country_id")
    private Integer countryId;

    @Column(name = "is_active", columnDefinition = "BIT(1) default b'1'" )
    private Boolean isActive;
}
