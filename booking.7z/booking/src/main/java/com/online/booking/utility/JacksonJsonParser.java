package com.online.booking.utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.online.booking.model.SeatStatus;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.Map;
import java.util.Optional;

//@ComponentScan(basePackages = {"com.online.booking.service.Impl"})
@Configuration
public class JacksonJsonParser {
    public Map<String, SeatStatus> readJsonData(Optional<String> seatStatusInJson) {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, SeatStatus> allSeatsStatus;
        try {
            allSeatsStatus = mapper.readValue(seatStatusInJson.get(), new TypeReference<Map<String, SeatStatus>>() {
            });
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return allSeatsStatus;
    }
        public String convertIntoJson(Map<String, SeatStatus> jsonDataInMap)
        {
            ObjectMapper mapper = new ObjectMapper();
        String jsonData = null;
        try {
            jsonData = mapper.writeValueAsString(jsonDataInMap);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
            return jsonData;
    }
}
