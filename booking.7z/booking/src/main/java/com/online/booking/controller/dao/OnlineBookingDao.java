package com.online.booking.controller.dao;

import com.online.booking.repository.OnlineBookingRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;

@Component
public class OnlineBookingDao  {

    @Autowired
    OnlineBookingRespository onlineBookingRespository;
    public Integer createBookingTicket(Integer theaterDetailsId, Timestamp bookingTime) {
        return onlineBookingRespository.createBookingTicket(theaterDetailsId, bookingTime);
    }

}
