package com.online.booking.controller.dao;

import com.online.booking.repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LocationDao {

    @Autowired
    LocationRepository locationRepository;
    public Long findByTownId(Integer townId) {
        return locationRepository.findByTownId(townId);
    }

}
