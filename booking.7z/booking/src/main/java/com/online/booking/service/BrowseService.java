package com.online.booking.service;

import com.online.booking.model.BookedByUser;
import java.util.List;
import java.util.Optional;

public interface BrowseService {

    public Optional<List<String>> browseTheatres(Integer selectedmovie , Integer city);
    public boolean bookTickets(BookedByUser bookedByUser) ;
}
