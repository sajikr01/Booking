package com.online.booking.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name ="payment_info")
public class PaymentInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name ="user_info")
    private Integer userInfoId;

    @Column(name ="online_booking_id")
    private Integer onlineBookingId;

    @Column(name ="payment_mode") // credit/debit/upi etc
    private String paymentMode;

    @Column(name ="in_voiceid")
    private String inVoiceId;

    @Column(name ="status")
    private String status;

    @Column(name ="payment_date_time")
    private String paymentDateTime;
}
